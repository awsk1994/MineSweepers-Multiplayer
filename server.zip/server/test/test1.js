var test2 = require('./test2.js');
console.log("test2: " + test2.x);
console.log("test1.js");