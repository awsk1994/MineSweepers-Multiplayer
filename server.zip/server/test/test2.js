
console.log("test2.js");

module.exports.x = true;